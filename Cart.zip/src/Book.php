<?php

namespace Cart;

class Book extends Product{
   
}