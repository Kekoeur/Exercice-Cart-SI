<?php

namespace Cart;

class Bike extends Product{
   
}