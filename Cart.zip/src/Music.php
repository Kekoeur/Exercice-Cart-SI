<?php

namespace Cart;

class Music extends Product{
  
}